import { navTo, setStorage } from './wxtools'

const WebIM = require("./WebIM")["default"];
const disp = require("./broadcast");
let systemReady = false;
module.exports = {
  goLogin(data, id) {
    wx.showModal({
      title: '提示',
      content: '请先登录',
      success(res) {
        if (res.confirm) {
          navTo('/pages/login/passLogin/passLogin')
          setStorage('loginToPageTips', data)
          setStorage('toPageId', id)
        }
      }
    })
  },
  getRoster(callback) {
    let rosters = {
      success(roster) {
        var member = [];
        for (let i = 0; i < roster.length; i++) {
          if (roster[i].subscription == "both") {
            member.push(roster[i]);
          }
        }
        console.log(member)
        callback(member)
        if (!systemReady) {
          disp.fire("em.main.ready");
          systemReady = true;
        }
      },
      error(err) {
        console.log("[main:getRoster]", err);
      }
    };
    // WebIM.conn.setPresence()
    WebIM.conn.getRoster(rosters);
  },
  computedCount(callback) { // 统计未读条数
    disp.on("em.xmpp.unreadspot", function (count) {
      callback(count)
    });
  }
}
