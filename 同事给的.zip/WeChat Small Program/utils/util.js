import { getNowFormatDate } from './common'
module.exports = {
  validatePhone(val) {
    val = val.trim()
    const reg = /^[1][0-9]{10}$/
    return reg.test(val)
  },
  timeDiff(faultDate, completeTime) {
    var faultDate = faultDate.replace(/-/g, '/');
    var completeTime = completeTime.replace(/-/g, '/');
    var stime = Date.parse(new Date(faultDate));
    var etime = Date.parse(new Date(completeTime));
    var usedTime = parseInt(etime - stime);  //两个时间戳相差的毫秒数
    var time = usedTime / 1000
    if (time <= 3600) {
      return "刚刚"
    }
    if (time > 3600 && time <= 7200) {
      return "1小时前"
    }
    if (time > 7200) {
      return parseInt(time / 3600) + "小时前"
    }
    if (time > 24 * 3600) {
      return "1天前"
    }
    if (time > 24 * 3600 * 7) {
      return getNowFormatDate(lastMsm)
    }
  }
}