module.exports = {
  showToasts(title, icon, duration) {
    wx.showToast({
      title,
      icon: icon || 'none',
      duration: duration || 2000
    })
  },
  showModals(msg) {
    wx.showModal({
      title: '提示',
      content: msg
    })
  },
  setStorage(key, data) {
    wx.setStorage({
      key,
      data
    });
  },
  remStorage(key) {
    wx.removeStorage({
      key,
    })
  },
  navTo(url) {
    wx.navigateTo({
      url
    })
  },
  navBack(url) {
    wx.navigateBack({
      url
    })
  },
  wxRequest(url, params, method, callback) {
    wx.request({
      url,
      data: {
        ...params || params
      },
      method,
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      success(res) {
        callback(res)
      }
    })
  },
  getSystemInfo(that) {
    let type = ''
    wx.getSystemInfo({
      success(res) {
        type = res.platform
      }
    })
    return type
  }
}
