
export function validaterName(val) {
  const reg = /^[\u4e00-\u9fa5_]{1,}$/
  return reg.test(val)
}