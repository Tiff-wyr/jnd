// pages/agent/mine/mine.js
const app = getApp()
var template = require('../../components/tabBar/index.js');
import { setStorage, navTo } from '../../utils/wxtools'
let WebIM = require("../../utils/WebIM")["default"];
Page({
  /**
   * 页面的初始数据
   */
  data: {
    userType: '',
    personData: {}
  },
  logout() {
    let that=this
    wx.showModal({
      title: '提示',
      content: '确认退出登录',
      success(res) {
        if (res.confirm) {
          WebIM.conn.close();
          app.globalData.userInfo = {}
          setStorage('loginPhone', '')
          setStorage('loginPassword', '')
          app.globalData.userType = 'user'
          wx.reLaunch({
            // url: '/pages/borrower/pages/loanApply/loanApply',
            url: '/pages/borrower/pages/loans/loans',
          })
        }
      }
    })
  },
  handleInfo(e) {
    const that = this
    const tips = e.currentTarget.dataset.tips
    if (app.globalData.userInfo.name) {
      if (tips === 'personInfo') {
        navTo('/pages/personMessage/personMessage')
      } else if (tips === 'applyRecord') {
        navTo('/pages/applyAcc/applyAcc')
      } else if (tips === 'proCen') {
        navTo('/pages/organ/pages/productCenter/productCenter')
      } else if (tips === 'myCollect') {
        navTo('/pages/borrower/pages/myCollect/myCollect')
      }
    } else {
      wx.showModal({
        title: '提示',
        content: '请先登录',
        success(res) {
          if (res.confirm) {
            that.handleLogin()
          }
        }
      })
    }
  },
  handleLogin() {
    navTo('/pages/login/passLogin/passLogin')
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let id = 3
    if (app.globalData.userType === 'user') {
      id = 2
    }
    template.tabbar("tabBar", id, this, app.globalData.userType)//0表示第一个tabbar
    this.setData({
      personData: app.globalData.userInfo,
      userType: app.globalData.userType,
      loginIdentity: this.judgeLoginIndentity()
    })
    
  },
  judgeLoginIndentity() {
    if (app.globalData.userType === 'user') {
      return '贷款人'
    } else if (app.globalData.userType === 'agent') {
      return '经纪人'
    } else {
      return '机构'
    }
  }
})