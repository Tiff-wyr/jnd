// pages/login/passLogin/passLogin.js
import { fetch } from "../../../utils/axios.js"
import { showToasts, setStorage, getSystemInfo, remStorage, navBack } from '../../../utils/wxtools'

let WebIM = require("../../../utils/WebIM")["default"];
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    phone: '',
    password: '',
    grant_type: "jnd"
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log(getSystemInfo())
    let phone = wx.getStorageSync("loginPhone")
    let password = wx.getStorageSync("loginPassword")
    if (phone && password) {
      this.setData({
        phone: phone,
        password: password,
      })
      this.login()
    }
  },
  msgLogin() {
    wx.navigateTo({
      url: '/pages/login/msgLogin/msgLogin',
    })
  },
  freeRe() {
    wx.navigateTo({
      url: '/pages/register/register',
    })
  },
  handlePhone(e) {
    this.setData({
      phone: e.detail.value
    })
  },
  handlePassword(e) {
    this.setData({
      password: e.detail.value
    })

  },
  login() {
    if (this.data.phone && this.data.password) {
      fetch.get(`/user/loginByPhoneAndPassword/${this.data.phone}/${this.data.password}/0`).then(res => {
        if (res.data.status !== 200) {
          showToasts('账号或密码错误')
        } else {
          showToasts('登录成功', 'success')
          setStorage('loginPhone', this.data.phone)
          setStorage('loginPassword', this.data.password)
          app.globalData.userInfo = res.data.data
          setStorage('myUsername', res.data.data.phone)
          getApp().conn.open({
            apiUrl: WebIM.config.apiURL,
            user: res.data.data.phone,
            pwd: '123456',
            grant_type: this.data.grant_type,
            appKey: WebIM.config.appkey
          });
          if (res.data.data.roleId === 1) { // 贷款人
            app.globalData.userType = 'user'
          }
          if (res.data.data.roleId === 2) { // 经纪人
            app.globalData.userType = 'agent'
          }
          if (res.data.data.roleId === 3) { // 机构
            app.globalData.userType = 'organ'
          }
          const data = wx.getStorageSync('loginToPageTips')
          const toPageId = wx.getStorageSync('toPageId')
          if (data && res.data.data.roleId === 1) {
            var pages = getCurrentPages()
            var prevPage
            for (let i = 0; i < pages.length; i++) {
              if (pages[i].route.match(data)) {
                prevPage = pages[i]
              }
            }
            prevPage.setData({
              optionId: toPageId,
              userId: res.data.data.id
            })
            navBack(`/pages/detail/${data}/${data}?id=${toPageId}`)
          } else {
            wx.reLaunch({
              url: '/pages/mine/mine'
            })
          }
        }
      })
    } else {
      showToast('不能为空')
    }
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    remStorage('loginToPageTips')
    remStorage('toPageId')
  }
})