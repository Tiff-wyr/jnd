// borrower/pages/loans/loans.js
const app = getApp()
var template = require('../../../../components/tabBar/index.js');
import { fetch } from "../../../../utils/axios.js"
import { showToasts } from '../../../../utils/wxtools'
Page({
  /**
   * 页面的初始数据
   */
  data: {
    tab: '2',
    index: '1',
    cityid: '1',
    indexZ: '0',
    idZ: '1',
    indexSearch: '0',// 搜索索引
    idSearch: '1',
    searchContent: '',
    page: 1,
    pageSize: 10,
    array: [],
    arr: [
      { id: 1, name: '最新' },
      { id: 2, name: '最热' },
    ],
    agentData: [],
    organData: [],
    proData: [],
    hasData: true
  },
  getCity() {
    fetch.get(`/city/getAHotCity`).then(res => {
      this.setData({
        array: res.data
      })
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    template.tabbar("tabBar", 0, this, app.globalData.userType) //0表示第一个tabbar
    this.getCity()
    this.getTable()
  },
  //城市选择
  bindPickerChange(e) {
    let index = e.detail.value
    let cityid = this.data.array[index].hid
    this.setData({
      index,
      cityid
    })
    this.getTable()
  },
  //最新 最热
  bindPickerZui(e) {
    let indexZ = e.detail.value
    let idZ = this.data.arr[indexZ].id
    this.setData({
      indexZ,
      idZ
    })
    this.getTable()
  },
  hanCon(e) {
    let con = e.detail.value
    this.setData({
      searchContent: con
    })
    this.getSorl()
  },
  getSorl(id) {
    const that = this
    if (this.data.searchContent) {
      fetch.get(`/solr/xcxSolrNoHighLight?roleId=${that.data.tab}&q=${that.data.searchContent}&page=${that.data.page}&pageSize=${that.data.pageSize}`).then(res => {
        if (that.data.tab === '2') {
          const arr = res.data.data
          for (let i = 0; i < arr.length; i++) {
            res.data.data[i].businessScopeInfo = arr[i].businessScopeInfo.split(',')
          }
          that.setData({
            agentData: res.data.data
          })
        } else if (that.data.tab === '3') {
          that.setData({
            organData: res.data.data
          })
        } else {
          that.setData({
            proData: res.data.data
          })
        }
      })
    }
  },
  resetData() {
    this.setData({
      page: 1,
      hasData: false
    })
  },
  //获取列表
  getTable(callback) {
    const that = this
    fetch.post('/screen/screen', {
      address: that.data.cityid,
      newOrHot: that.data.idZ,
      roleId: that.data.tab,
      page: that.data.page,
      pageSize: that.data.pageSize
    }).then(res => {
      if (res.data.status === 200) {
        if (callback) {
          callback()
        }
        if (that.data.tab === '2') {
          const arr= res.data.data.rows
          if (arr.length < that.data.pageSize) {
            that.setData({
              hasData: false
            })
          } else {
            that.setData({
              hasData: true
            })
          }
          for (let i = 0; i < arr.length; i++) {
            res.data.data.rows[i].businessScopeInfo = arr[i].businessScopeInfo.split(',')
          }
          that.setData({
            agentData: res.data.data.rows
          })
        } else if (that.data.tab === '3') {
          if (res.data.data.list.length < that.data.pageSize) {
            that.setData({
              hasData: false
            })
          } else {
            that.setData({
              hasData: true
            })
          }
          that.setData({
            organData: res.data.data.list
          })
        } else {
          if (res.data.data.list.length < that.data.pageSize) {
            that.setData({
              hasData: false
            })
          } else {
            that.setData({
              hasData: true
            })
          }
          that.setData({
            proData: res.data.data.list
          })
        }
      }
    })
  },
  /**
   * tab 选项卡点击事件
   */
  handlerTabClick(e) {
    let tab = e.currentTarget.dataset.id
    this.setData({
      tab
    })
    this.resetData()
    this.getTable()
  },
  handleAgent(e) {
    if (app.globalData.userInfo.id !== '') {
      fetch.get(`/brokerBrowsedRecord/saveRecord/${e.currentTarget.dataset.id}/${app.globalData.userInfo.id}`)
    }
    wx.navigateTo({
      url: `/pages/detail/agentDetail/agentDetail?id=${e.currentTarget.dataset.id}`,
    })
  },
  handleOrgan(e) {
    if (app.globalData.userInfo.id !== '') {
      fetch.post(`/borLook/addLook`, { borId: app.globalData.userInfo.id, agencyId: e.currentTarget.dataset.id })
    }
    wx.navigateTo({
      url: `/pages/detail/organDetail/organDetail?id=${e.currentTarget.dataset.id}`,
    })
  },
  handlePro(e) {
    if (app.globalData.userInfo.id !== '') {
      fetch.post(`/borLookPro/addLookPro`, { borId: app.globalData.userInfo.id, proId: e.currentTarget.dataset.id })
    }
    wx.navigateTo({
      url: `/pages/detail/productDetail/productDetail?id=${e.currentTarget.dataset.id}`,
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (options) {
    return {
      imageUrl: '/static/icon/tu.png',
      title: '为您的贷款之路保驾护航'
    }
  },
  onPullDownRefresh() {
    this.setData({
      page: 1,
      pageSize: 10
    })
    wx.showNavigationBarLoading()
    this.getTable(() => {
      wx.stopPullDownRefresh()
      wx.hideNavigationBarLoading()
      showToasts('刷新成功')
    })
  },
  onReachBottom() {
    const that = this
    if (this.data.hasData) {
      let page = this.data.page
      page++
      this.setData({
        page
      })
      fetch.post('/screen/screen', {
        address: that.data.cityid,
        newOrHot: that.data.idZ,
        roleId: that.data.tab,
        page: that.data.page,
        pageSize: that.data.pageSize
      }).then(res => {
        if (res.data.status === 200) {
          if (that.data.tab === '2') {
            let voteList = that.data.agentData;
            for (let i = 0; i < res.data.data.rows.length; i++) {
              res.data.data.rows[i].businessScopeInfo = res.data.data.rows[i].businessScopeInfo.split(',')
            }
            if (res.data.data.rows.length > 0) {
              voteList = voteList.concat(res.data.data.rows);
              if (res.data.data.rows.length < that.data.pageSize) { // 已无数据
                that.setData({
                  agentData: voteList,
                  hasData: false
                });
                showToasts('没有更多了')
              } else {
                that.setData({  // 仍有下一页数据,则hasData设置为true
                  agentData: voteList,
                  hasData: true
                });
              }
              
              console.log(voteList)
            }
          } else if (that.data.tab === '3') {
            let voteList = that.data.organData;
            if (res.data.data.list.length > 0) {
              voteList = voteList.concat(res.data.data.list);
              if (res.data.data.list.length < that.data.pageSize) { // 已无数据
                that.setData({
                  organData: voteList,
                  hasData: false
                });
                showToasts('没有更多了')
              } else {
                that.setData({  // 仍有下一页数据,则hasData设置为true
                  organData: voteList,
                  hasData: true
                });
              }
            }
          } else {
            let voteList = that.data.proData;
            if (res.data.data.list.length > 0) {
              voteList = voteList.concat(res.data.data.list);
              if (res.data.data.list.length < that.data.pageSize) { // 已无数据
                that.setData({
                  proData: voteList,
                  hasData: false
                });
                showToasts('没有更多了')
              } else {
                that.setData({  // 仍有下一页数据,则hasData设置为true
                  proData: voteList,
                  hasData: true
                });
              }
            }
          }
        }
      })
    }
  }
})