// pages/activity/activity.js
import { getNowFormatDate } from '../../utils/common'
import { navTo } from '../../utils/wxtools'
const promisify = require('../../utils/promisify')
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    canvasHeight: 0,
    canvasWidth: 0,
    canvasShow: true,
    isFinih: false,
    isShare: false,
    endTime: new Date('2019-05-25 00:00:00'),
    hour: '00',
    min: '00',
    seconds: '00'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    wx.showShareMenu({
      withShareTicket: true
    })
    if (options.isShare) {
      this.setData({
        isShare: true
      })
    }
    const endTime = new Date('2019-05-25 00:00:00').getTime()
    setInterval(() => {
      let nowTime = new Date().getTime()
      let timeRemaining = endTime - nowTime // 剩余秒数
      let hour = parseInt(timeRemaining / 60 / 60 / 1000) // 剩余小时数
      let min = parseInt(timeRemaining / 60 / 1000 % 60) // 剩余分钟数
      let seconds = parseInt(timeRemaining / 1000 % 60) // 剩余秒数
      if (seconds < 10) {
        seconds = '0' + seconds
      }
      if (min < 10) {
        min = '0' + min
      }
      if (hour < 10) {
        hour = '0' + hour
      }
      this.setData({
        hour,
        min,
        seconds
      })
    }, 1000);
  },
  handleActivity() { // 我也要专属经纪人
    if (app.globalData.userInfo.id) {
      return
    }
    navTo('../login/passLogin/passLogin')
  },
  downloadFile() {
    this.setData({
      canvasShow: true
    })
    
    wx.createSelectorQuery().selectAll('.wrap').boundingClientRect(rect => {
      this.setData({
        canvasHeight: rect[0].height,
        canvasWidth: rect[0].width
      })
    }).exec()
    
    const wxGetImageInfo = promisify(wx.getImageInfo)
    wxGetImageInfo({
      src: ''
    }).then(res => {
      const ctx = wx.createCanvasContext('shareCanvas')
      ctx.drawImage(res.path, 0, 0, this.data.canvasWidth, 400)
      ctx.setFillStyle('#4A4A4A') // 文字颜色：黑色
      ctx.setFontSize(14) // 文字字号：22px
      ctx.fillText("活动规则", 20, 420)
      ctx.stroke()
      ctx.draw()
    }).then(() => {
      const wxCanvasToTempFilePath = promisify(wx.canvasToTempFilePath)
      const wxSaveImageToPhotosAlbum = promisify(wx.saveImageToPhotosAlbum)
      wxCanvasToTempFilePath({
        canvasId: 'shareCanvas'
      }, this).then(res => {
        return wxSaveImageToPhotosAlbum({
          filePath: res.tempFilePath
        })
      }).then(res => {
        wx.showToast({
          title: '已保存到相册'
        })
      })
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
    }
    return {
      title: '9能贷活动助力',
      path: `pages/activity/activity?userId=${1}&isShare=${true}`,
      success(res) {
        console.log('活动助力分享成功')
      }
    }
  }
})