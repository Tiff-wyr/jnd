// // pages/agent/message/message.js
const app = getApp()
var template = require('../../../../components/tabBar/index.js');
let disp = require("../../../../utils/broadcast");
let { getNowFormatDate } = require("../../../../utils/common.js")
let WebIM = require("../../../../utils/WebIM.js")["default"];
import { fetch } from '../../../../utils/axios'
Page({
  data: {
    yourname: "",
    unReadSpot: false,
    arr: [],
    isLogin: false
  },
  login() {
    wx.navigateTo({
      url: '/pages/login/passLogin/passLogin',
    })
  },

  onLoad() {
    let me = this;
    if (app.globalData.userType === 'user') {
      template.tabbar("tabBar", 1, this, app.globalData.userType)
    } else {
      template.tabbar("tabBar", 2, this, app.globalData.userType)
    }
    if (app.globalData.userInfo.name) {
      disp.on("em.xmpp.unreadspot", function (count) {
        me.getChatList()
        me.setData({
          isLogin: true,
          unReadSpot: count > 0
        });
      });

    } else {
      me.setData({
        isLogin: false
      })
    }


  },
  getChatList() {
    var array = [];
    var time = WebIM.time();
    var member = wx.getStorageSync("member");
    var myName = wx.getStorageSync("myUsername");
    const phoneArr = []
    const that = this
    var objectArraySort = function (keyName) {
      return function (objectN, objectM) {
        var valueN = objectN[keyName]
        var valueM = objectM[keyName]
        if (valueN < valueM) return 1
        else if (valueN > valueM) return -1
        else return 0
      }
    }
    function timeDiff(faultDate, completeTime) {
      var faultDate = faultDate.replace(/-/g, '/');
      var completeTime = completeTime.replace(/-/g, '/');
      var stime = Date.parse(new Date(faultDate));
      var etime = Date.parse(new Date(completeTime));
      var usedTime = parseInt(etime - stime);  //两个时间戳相差的毫秒数
      var time = usedTime / 1000
      return time;
    }
    for (let i = 0; i < member.length; i++) {
      phoneArr.push(member[i].name)
    }
    fetch.post(`/user/getNameLogo`, {
      phone: phoneArr.join(',')
    }).then(res => {
      console.log(res)
      for (let i = 0; i < member.length; i++) {
        if (member[i].name != undefined && member[i].name != 'undefined' && member[i].name != null) {
          let newChatMsgs = wx.getStorageSync(member[i].name + myName) || [];
          let historyChatMsgs = wx.getStorageSync("rendered_" + member[i].name + myName) || [];
          let curChatMsgs = historyChatMsgs.concat(newChatMsgs);
          if (curChatMsgs.length) {
            let lastChatMsg = curChatMsgs[curChatMsgs.length - 1];
            lastChatMsg.unReadCount = newChatMsgs.length;
            if (lastChatMsg.unReadCount > 10) {
              lastChatMsg.unReadCount = "...";
            }
            let lastMsm = lastChatMsg.time
            for (let j = 0; j < res.data.length; j++) {
              if (res.data[j].phone !== undefined && res.data[j].phone === member[i].name) {
                lastChatMsg.nickname = res.data[j].name;
                lastChatMsg.logoImg = res.data[j].logo;
                lastChatMsg.roleId = res.data[j].roleId;
                lastChatMsg.userId = res.data[j].userId;
              }
            }
            if (parseInt(timeDiff(lastMsm, time)) <= 3600) {
              lastChatMsg.showTime = "刚刚"
            }
            if (timeDiff(lastMsm, time) > 3600 && timeDiff(lastMsm, time) <= 7200) {
              lastChatMsg.showTime = "1小时前"
            }
            if (timeDiff(lastMsm, time) > 7200) {
              lastChatMsg.showTime = parseInt(timeDiff(lastMsm, time) / (3600)) + "小时前"
            }
            if (timeDiff(lastMsm, time) > 24 * 3600) {
              lastChatMsg.showTime = "1天前"
            }
            if (timeDiff(lastMsm, time) > 24 * 3600 * 7) {
              lastChatMsg.showTime = getNowFormatDate(lastMsm)
            }
            array.push(lastChatMsg);
          }
        }
      }
      that.setData({
        arr: array.sort(objectArraySort('time'))
      })
    })
  },
  onShow: function () {
    if (app.globalData.userInfo.name) {
      this.getChatList()
      this.setData({
        isLogin: true,
        unReadSpot: getApp().globalData.unReadSpot,
      });
    } else {
      this.setData({
        isLogin: false
      })
    }


  },
  into_chatRoom: function (event) {
    let my = wx.getStorageSync("myUsername");
    let nameList = {
      myName: my,
      your: event.currentTarget.dataset.phone,
      yourName: event.currentTarget.dataset.name,
      myLogo: app.globalData.userInfo.image,
      yourLogo: event.currentTarget.dataset.yourlogo,
      userId: event.currentTarget.dataset.userid,
      roleId: event.currentTarget.dataset.roleid
    };
    if (nameList.roleId === 1) {
      app.globalData.chatTargetType = 'user'
    } else if (nameList.roleId === 2) {
      app.globalData.chatTargetType = 'agent'
    } else {
      app.globalData.chatTargetType = 'organ'
    }
    console.log(nameList)
    wx.navigateTo({
      url: "/pages/chatroom/chatroom?myName=" + nameList.myName + "&your=" + nameList.your + "&yourName=" + nameList.yourName + "&usertype=B&selfHeadImg=" + nameList.myLogo + "&yourLogo=" + nameList.yourLogo + '&userId=' + nameList.userId
    });
  },
});
