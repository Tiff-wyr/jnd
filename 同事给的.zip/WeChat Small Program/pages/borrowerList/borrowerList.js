// pages/agent/borrower/borrower.js
const app = getApp()
var template = require('../../components/tabBar/index.js');
import { fetch } from "../../utils/axios.js"
import { showToasts } from '../../utils/wxtools'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tableData: [],
    index: 0,
    id: 0,
    indexZ: 0,
    indexM: 0,
    idM: 0,
    page: 1,
    size: 10,
    arrM: [],
    array: [],
    arr: [
      { id: 1, name: '最新' },
      { id: 2, name: '最热' }
    ],
    listQuery: {
      currentPage: 1,
      pageSize: 10,
      ageOrBroId: '',
      roleId: '',
      amount: '',
      condition: 1,
      address: ''
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    template.tabbar("tabBar", 0, this, app.globalData.userType) //0表示第一个tabbar
    this.setData({
      'listQuery.ageOrBroId': app.globalData.userInfo.id,
      'listQuery.roleId': app.globalData.userInfo.roleId
    })
    this.getCity()
    this.getMoney()
    this.getList()
  },
  getList(callback) {
    fetch.post('/userBorrower/wxGetBor', this.data.listQuery).then(res => {
      this.setData({
        tableData: res.data.list
      })
      if (callback) {
        callback()
      }
    })
  },
  getCity() {
    fetch.get(`/city/getAHotCity`).then(res => {
      this.setData({
        array: res.data
      })
    })
  },
  getMoney() {
    fetch.get(`/get/getAmount`).then(res => {
      this.setData({
        arrM: res.data
      })
    })
  },

  /**
   * 选择框change事件
   */
  // 城市 选择
  bindPickerChange(e) {
    let index = e.detail.value
    let id = this.data.array[index].hid
    this.setData({
      index,
      'listQuery.address': id
    })
    this.getList()
  },
  // 最新 最热 选择
  bindPickerZui(e) {
    let indexZ = e.detail.value
    let idZ = this.data.arr[indexZ].id
    this.setData({
      indexZ,
      'listQuery.condition': idZ
    })
    this.getList()
  },
  // 金钱 选择
  bindPickerMon(e) {
    let indexM = e.detail.value
    let idM = this.data.arrM[indexM].id
    this.setData({
      indexM,
      'listQuery.amount': idM
    })
    this.getList()
  },

  //进入贷款人详情页
  handlerClickDetail(event) {
    wx.navigateTo({
      url: `/pages/detail/borrowerDetail/borrowerDetail?borId=${event.currentTarget.dataset.id}&type=1`,
    })
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    wx.showNavigationBarLoading();
    this.setData({
      'listQuery.currentPage': 1,
      'listQuery.pageSize': 10
    })
    this.getList(showToasts('刷新成功'))
    wx.stopPullDownRefresh();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  upLoading() {
    fetch.post('/userBorrower/wxGetBor', this.data.listQuery).then(res => {
      let newList = [...this.data.tableData, ...res.data.list]
      this.setData({
        tableData: newList
      })
      wx.hideLoading();
    })
  },
  onReachBottom: function () {
    wx.showLoading({
      title: '玩命加载中',
    })
    let currentPage = this.data.listQuery.currentPage
    currentPage++
    this.setData({
      'listQuery.currentPage': currentPage
    })
    if (this.data.tableData.length % 10 > 0) {
      wx.hideLoading()
      showToasts('没有更多数据了...')
      return
    }
    this.upLoading()
  }
})