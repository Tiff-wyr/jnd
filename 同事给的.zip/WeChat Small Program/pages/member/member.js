// pages/agent/member/member.js
const app = getApp()
var template = require('../../components/tabBar/index.js');
import { fetch } from "../../utils/axios.js"

Page({

  /**
   * 页面的初始数据
   */
  data: {
    isKai: false,
    src1: '/static/icon/1.png',
    src2: '/static/icon/2.png',
    src3: '/static/icon/3.png',
    src4: '/static/icon/4.png',
    personData: {},
    isShow: true,
    money: '',
    isMem: false,
    businessType: '',
    vipType: '',
    vipLevel: ''
  },
  handleLogin() {
    wx.navigateTo({
      url: '/pages/login/passLogin/passLogin',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    template.tabbar("tabBar", 1, this, app.globalData.userType)//0表示第一个tabbar
    let that = this
    that.setData({
      personData: app.globalData.userInfo,
      vipLevel: app.globalData.userInfo.vip
    })
    wx.login({
      success: function (res) {
        that.getOpenId(res.code);
      }
    })
    this.getVipList()
    wx.getSystemInfo({
      success(res) {
        if (res.platform === 'android' || res.platform === 'devtools') {
          that.setData({
            isShow: true
          })
        } else {
          that.setData({
            isShow: false
          })
        }
      }
    })
  },
  getVipList() {
    fetch.get(`/paySet/getXcxPrice/${app.globalData.userInfo.phone}`).then(res => {
      const vipList = res.data.map(k => {
        if (k.vid === 0) {
          k.vipName = '购买单次'
          k.businessType = '购买'
        }
        if (k.vid === 1) {
          k.vipName = '会员'
        }
        if (k.vid === 2) {
          k.vipName = '高级会员'
        }
        if (k.vid === 3) {
          k.vipName = '超级会员'
        }
        if (app.globalData.userInfo.vip === 0) {
          k.businessType = '开通'
        } else {
          if (k.vid == this.data.personData.vip) {
            k.businessType = '续费'
          } 
          if (k.vid > this.data.personData.vip) {
            k.businessType = '升级'
          }
          if (k.vid < this.data.personData.vip) {
            k.businessType = '开通'
          }
        }
        return k
      })
      this.setData({
        vipList
      })
    })
  },
  //获取openid
  getOpenId: function (code) {
    fetch.post('/wxPay/getOpenId', {
      code
    }).then(res => {
      console.log(res)
      this.setData({
        openId: res.data.openid
      })
    })
  },
  handlePay(event) {
    this.setData({
      isKai: true
    })
    setTimeout(() => {
      this.setData({
        isKai: false
      })
    }, 5000);
    this.setData({
      money: event.currentTarget.dataset.price,
      vipType: event.currentTarget.dataset.id
    })
    this.getType(event.currentTarget.dataset.id)
    this.xiaDan();
  },
  getType(targetLevel) {
    const nowLevel = app.globalData.userInfo.vip
    if (nowLevel === 0 && targetLevel !== 0) {
      this.setData({
        businessType: 0,
        vipLevel: targetLevel
      })
    } else {
      // targetLevel 点击的等级(app.globalData.userInfo.vip 当前等级
      if (targetLevel === 0) { // 购买单次
        this.setData({
          businessType: 3
        })
      } else if (targetLevel === nowLevel) { // 续费
        this.setData({
          businessType: 1
        })
      } else if (targetLevel > nowLevel) { // 升级
        this.setData({
          businessType: 2
        })
      }
    }
  },
  //下单
  xiaDan() {
    let data = {
      openId: this.data.openId,
      phone: app.globalData.userInfo.phone,
      vipType: this.data.vipLevel,
      businessType: this.data.businessType,
      upVipType: this.data.vipType,
      month: 1
    }
    if (data.businessType !== 2) {
      delete data.upVipType
    }
    fetch.post('/wxPay/xiaDan', data).then(res => {
      this.sign(res.data.prepay_id);
    })
  },

  //签名
  sign: function (prepay_id) {
    fetch.post('/wxPay/sign', {
      repay_id: prepay_id
    }).then(res => {
      this.requestPayment(res.data);
    })
  },
  //付款
  requestPayment: function (obj) {
    wx.requestPayment({
      timeStamp: obj.timeStamp,
      nonceStr: obj.nonceStr,
      package: obj.package,
      signType: obj.signType,
      paySign: obj.paySign,
      success: function (res) {
        console.log('付款最后一步接口', res)
        this.getVipList()
      },
    })
  },
})