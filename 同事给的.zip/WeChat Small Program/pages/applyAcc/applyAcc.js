// borrower/pages/applyAccord/applyAccord.js
const app = getApp()
import { fetch } from "../../utils/axios"
import { navTo, showToasts } from '../../utils/wxtools'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tableData: [],
    page: 1,
    size: 10,
    userType: ''
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    this.setData({
      userType: app.globalData.userType
    })
    this.getData()
  },
  getData(callback) {
    if (this.data.userType === 'user') {
      this.getUserList(callback)
    } else if (this.data.userType === 'organ') {
      this.getOrganList(callback)
    } else {
      this.getAgentList(callback)
    }
  },
  getUserList(callback) {
    fetch.get(`/orderAll/getOrderByBorrowerId/${app.globalData.userInfo.id}/${this.data.page}/${this.data.size}`).then(res => {
      let arr = [...this.data.tableData, ...res.data.data.list]
      this.setData({ // 借款人
        tableData: arr
      })
      if (callback) {
        callback()
      }
    })
  },
  getOrganList(callback) { // 机构列表
    fetch.get(`/orderAll/getOrderByAgency/${app.globalData.userInfo.id}/${this.data.page}/${this.data.size}`).then(res => {
      let arr = [...this.data.tableData, ...res.data.data.list]
      console.log(arr)
      this.setData({
        tableData: arr
      })
      if (callback) {
        callback()
      }
    })
  },
  getAgentList(callback) { // 经纪人列表
    fetch.get(`/orderAll/getPageOrderByBrokerId/${app.globalData.userInfo.id}/${this.data.page}/${this.data.size}`).then(res => {
      let arr = [...this.data.tableData, ...res.data.rows]
      this.setData({
        tableData: arr
      })
      if (callback) {
        callback()
      }
    })
  },
  enter(event) {
    const roleId = event.currentTarget.dataset.roleid
    if (this.data.userType !== 'user') {
      const orderId = event.currentTarget.dataset.orderid
      navTo(`/pages/detail/borrowerDetail/borrowerDetail?orderId=${orderId}&type=2`)
    }  else {
      const id = event.currentTarget.dataset.agebroid
      if (roleId === 2){ // 经纪人详情
        navTo(`/pages/detail/agentDetail/agentDetail?id=${id}`)
      }
      if (roleId === 3) { // 机构详情
        navTo(`/pages/detail/organDetail/organDetail?id=${id}`)
      }
      if (roleId === 4) { // 产品详情
        navTo(`/pages/detail/productDetail/productDetail?id=${id}`)
      }
    }
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.data.tableData = []
    wx.showNavigationBarLoading();
    this.setData({
      page: 1,
      size: 10
    })
    this.getData(() => {
      showToasts('刷新成功')
      wx.hideNavigationBarLoading();
      wx.stopPullDownRefresh();
    })
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    wx.showLoading({
      title: '玩命加载中',
    })
    let num = this.data.page
    num++
    this.setData({
      page: num
    })
    console.log(this.data.tableData)
    if (this.data.tableData.length % 10 > 0) {
      wx.hideLoading()
      showToasts('没有更多数据了...')
      return
    }
    this.getData(() => {
      wx.hideLoading();
    })
  }
})