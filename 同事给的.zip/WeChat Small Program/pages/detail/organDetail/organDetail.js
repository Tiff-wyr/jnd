// borrower/pages/agentDetail/agentDetail.js
import { fetch } from "../../../utils/axios.js"
import { showToasts, navTo, wxRequest } from '../../../utils/wxtools'
import { goLogin, computedCount, getRoster } from '../../../utils/comMethods'
const app = getApp()

Page({
  /**
   * 页面的初始数据
   */
  data: {
    organ: {},
    myName: '',
    unReadSpot: 0,
    member: [],
    victory: [],
    userId: '',
    optionId: '',
    isCollect: false,
    proData: []
  },
  getDetail(id) {
    fetch.get(`/userAgency/selectUserAgencyById/${id}`).then(res => {
      this.setData({
        organ: res.data
      })
    })
  },
  getVictory(id) {
    fetch.get(`/orderAll/getAgencySuccessOrder/${id}`).then(res => {
      this.setData({
        victory: res.data
      })
    })
  },
  //代理产品
  getPro(id) {
    fetch.get(`/product/selectProductByAgency/${id}/1/4`).then(res => {
      this.setData({
        proData: res.data.list
      })
    })
  },
  proDetail(e) {
    wx.navigateTo({
      url: `/pages/detail/productDetail/productDetail?id=${e.currentTarget.dataset.id}`,
    })
  },
  //收藏
  restoreClick() {
    let that = this
    if (this.data.userId) {
      const url = app.globalData.baseUrl + '/borAgency/addBorAgency'
      const params = {
        borId: this.data.userId,
        agencyId: this.data.optionId
      }
      wxRequest(url, params, 'post', (res) => {
        if (res.data.status === 200) {
          showToasts('收藏成功', 'success')
          that.collectPan(that.data.optionId)
        }
      })
    } else {
      goLogin('organDetail', that.data.optionId)
    }
  },
  //取消收藏
  cancelColl() {
    let that = this
    if (this.data.userId) {
      const url = app.globalData.baseUrl + '/borAgency/deleteBorAgency'
      const params = {
        borId: this.data.userId,
        agencyId: this.data.optionId
      }
      wxRequest(url, params, 'post', (res) => {
        if (res.data.status === 200) {
          showToasts('取消成功', 'success')
          that.collectPan(that.data.optionId)
        }
      })
    } else {
      goLogin('organDetail', that.data.optionId)
    }
  },
  //收藏判断
  collectPan() {
    let that = this
    const url = app.globalData.baseUrl + '/borAgency/selectBorAgency'
    const params = {
      borId: this.data.userId,
      agencyId: this.data.optionId
    }
    if (this.data.userId) {
      wxRequest(url, params, 'post', (res) => {
        if (res.data === 0) {
          that.setData({
            isCollect: false
          })
        } else {
          that.setData({
            isCollect: true
          })
        }
      })
    }
  },
  //借款人向此机构申请
  apply() {
    navTo(`/pages/loanApply/loanApply?id=${this.data.optionId}&roleId=3`)
  },

  //立即沟通
  chat(event) {
    if (this.data.userId) {
      let my = wx.getStorageSync("myUsername");
      let nameList = {
        myName: my,
        your: event.currentTarget.dataset.phone,
        yourName: event.currentTarget.dataset.name,
        myLogo: app.globalData.userInfo.image,
        yourLogo: event.currentTarget.dataset.yourlogo
      };
      navTo("/pages/chatroom/chatroom?myName=" + nameList.myName + "&your=" + nameList.your + "&yourName=" + nameList.yourName + "&usertype=B&selfHeadImg=" + nameList.myLogo + "&yourLogo=" + nameList.yourLogo)
    } else {
      goLogin('organDetail', this.data.optionId)
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      optionId: options.id
    })
    //获得 机构详情信息
    this.getDetail(this.data.optionId)
    this.getVictory(this.data.optionId)
    this.getPro(this.data.optionId)
    if (app.globalData.userInfo) {
      this.setData({
        userId: app.globalData.userInfo.id,
        myName: app.globalData.userInfo.phone
      })
      //收藏判断
      this.collectPan(options.id)
    }
    const that = this
    computedCount((count) => {
      that.setData({
        unReadSpot: count
      });
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      unReadSpot: app.globalData.unReadSpot
    });
    this.getRoster();
  },
  getRoster() {
    let me = this;
    getRoster((member) => {
      me.setData({
        member
      });
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    wx.showShareMenu({
      withShareTicket: true
    })
  }
})