// pages/organ/productDetail/productDetail.js
import { fetch } from "../../../utils/axios.js"
import { showToasts, navTo, wxRequest, setStorage } from '../../../utils/wxtools'
import { goLogin, getRoster, computedCount } from '../../../utils/comMethods'
const app = getApp()

Page({
  /**
   * 页面的初始数据
   */
  data: {
    product: {},
    optionId: '',
    productBelong: '',
    organMess: {},
    userId: '',
    isCollect: false,
    myName: '',
    unReadSpot: 0,
    member: [],
    bottomShow: false
  },
  //立即沟通
  chat(event) {
    if (this.data.userId) {
      let my = wx.getStorageSync("myUsername");
      let nameList = {
        myName: my,
        your: event.currentTarget.dataset.phone,
        yourName: event.currentTarget.dataset.name,
        myLogo: app.globalData.userInfo.image,
        yourLogo: event.currentTarget.dataset.yourlogo
      };
      navTo("/pages/chatroom/chatroom?myName=" + nameList.myName + "&your=" + nameList.your + "&yourName=" + nameList.yourName + "&usertype=B&selfHeadImg=" + nameList.myLogo + "&yourLogo=" + nameList.yourLogo)
    } else {
      goLogin('productDetail', that.data.optionId)
    }
  },

  //借款人向此产品申请
  apply(event) {
    const that = this
    if (app.globalData.userInfo.id !== '' && app.globalData.userInfo.id !== undefined) {
      fetch.post(`/orderAll/saveProductOrder`, {
        borrowerId: app.globalData.userInfo.id,
        productId: event.currentTarget.dataset.id
      }).then(res => {
        if (res.data.status === 200) {
          showToasts('申请成功')
        } else {
          showToasts(res.data.msg)
        }
      })
    } else {
      goLogin('productDetail', that.data.optionId)
    }
  },
  //进入机构详情
  organDetail(e) {
    navTo(`/pages/detail/organDetail/organDetail?id=${e.currentTarget.dataset.id}`)
  },
  getDetail(id) {
    fetch.get(`/product/selectProductById/${id}`).then(res => {
      this.setData({
        product: res.data,
        productBelong: res.data.productBelong
      })
      this.getOrganDetail()
    })
  },
  getOrganDetail() {
    fetch.get(`/userAgency/selectUserAgencyById/${this.data.productBelong}`).then(res => {
      this.setData({
        organMess: res.data
      })
    })
  },
  //收藏
  restoreClick() {
    let that = this
    if (this.data.userId) {
      const params = {
        borId: this.data.userId,
        productId: this.data.optionId
      }
      wxRequest('https://www.rjkf001.com/borpro/addBorPro', params, 'post', (res) => {
        if (res.data.status === 200) {
          showToasts('收藏成功', 'success')
          that.collectPan(that.data.optionId)
        }
      })
    } else {
      goLogin('productDetail', that.data.optionId)
    }

  },
  //取消收藏
  cancelColl() {
    let that = this
    const params = {
      borId: that.data.userId,
      productId: that.data.optionId
    }
    if (that.data.userId) {
      wxRequest('https://www.rjkf001.com/borpro/deleteBorPro', params, 'post', (res) => {
        if (res.data.status === 200) {
          showToasts('取消成功', 'success')
          that.collectPan(that.data.optionId)
        }
      })
    } else {
      goLogin('productDetail', that.data.optionId)
    }
  },
  //收藏判断
  collectPan() {
    let that = this
    if (that.data.userId) {
      const params = {
        borId: that.data.userId,
        productId: that.data.optionId
      }
      wxRequest('https://www.rjkf001.com/borpro/selectBorPro', params, 'post', (res) => {
        if (res.data === 0) {
          that.setData({
            isCollect: false
          })
        } else {
          that.setData({
            isCollect: true
          })
        }
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    this.setData({
      optionId: options.id
    })
    if (options.from) {
      this.setData({
        bottomShow: true
      })
    }
    this.getDetail(this.data.optionId)
    if (app.globalData.userInfo.name) {
      this.setData({
        userId: app.globalData.userInfo.id,
        myName: app.globalData.userInfo.phone
      })
    }
    this.collectPan()
    let that = this
    computedCount((count) => {
      that.setData({
        unReadSpot: count
      });
    })
  },
  
  look() {
    this.setData({
      isMask: true
    })
  },
  cancel() {
    this.setData({
      isMask: false
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      unReadSpot: getApp().globalData.unReadSpot
    });
    this.getRoster();
  },
  getRoster() {
    let me = this;
    getRoster((member) => {
      me.setData({
        member
      });
    })
  }
})