// borrower/pages/agentDetail/agentDetail.js
import { fetch } from "../../../utils/axios.js"
import { showToasts, navTo, wxRequest } from '../../../utils/wxtools'
import { goLogin, getRoster, computedCount } from '../../../utils/comMethods'
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    agent: {},
    member: [],
    victory: [],
    userId: '',
    optionId: '',
    isCollect: false,
    myName: '',
    unReadSpot: 0,
  },
  getDetailAgent(id) {
    fetch.get(`/orderAll/getOrderByOrderId/${id}`).then(res => {
      console.log(res)
    })
    fetch.get(`/userBroker/getUserBrokerById/${id}`).then(res => {
      res.data.businessScopeInfo = res.data.businessScopeInfo.split(',')
      this.setData({
        agent: res.data
      })
      //经纪人成功案例
      this.getVictory(this.data.optionId)
    })
  },
  getVictory(id) {
    fetch.get(`/orderAll/getTopSixOrderByBrokerId/${id}`).then(res => {
      this.setData({
        victory: res.data
      })
    })
  },
  //收藏
  restoreClick() {
    let that = this
    if (this.data.userId) {
      const url = app.globalData.baseUrl + '/borrowerKeep/saveBorrowerKeep'
      const params = {
        borrowerId: this.data.userId,
        brokerId: this.data.optionId
      }
      wxRequest(url, params, 'post', (res) => {
        if (res.data.status === 200) {
          showToasts('收藏成功', 'success')
          that.collectPan(that.data.optionId)
        }
      })
    } else {
      goLogin('agentDetail', that.data.optionId)
    }
  },
  //取消收藏
  cancelColl() {
    let that = this
    if (this.data.userId) {
      fetch.get(`/borrowerKeep/removeBorrowerKeepById/${this.data.userId}/${this.data.optionId}`).then(res => {
        if (res.data.status === 200) {
          showToasts('取消成功', 'success')
          that.collectPan(that.data.optionId)
        }
      })
    } else {
      goLogin('agentDetail', that.data.optionId)
    }
  },
  //收藏判断
  collectPan(id) {
    let that = this
    if (this.data.userId) {
      fetch.get(`/borrowerKeep/checkBorrowerKeepBroker/${this.data.userId}/${id}`).then(res => {
        if (res.data === 0) {
          that.setData({
            isCollect: false
          })
        } else {
          that.setData({
            isCollect: true
          })
        }
      })
    }
  },

  //立即沟通
  chat(event) {
    if (this.data.userId) {
      let my = wx.getStorageSync("myUsername");
      let nameList = {
        myName: my,
        your: event.currentTarget.dataset.phone,
        yourName: event.currentTarget.dataset.name,
        myLogo: app.globalData.userInfo.image,
        yourLogo: event.currentTarget.dataset.yourlogo
      };
      navTo("/pages/chatroom/chatroom?myName=" + nameList.myName + "&your=" + nameList.your + "&yourName=" + nameList.yourName + "&usertype=B&selfHeadImg=" + nameList.myLogo + "&yourLogo=" + nameList.yourLogo)
    } else {
      goLogin('agentDetail', this.data.optionId)
    }
  },

  //借款人向此经纪人申请
  apply() {
    navTo(`/pages/loanApply/loanApply?id=${this.data.optionId}&roleId=2`)
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      optionId: options.id
    })
    //经纪人详情页
    this.getDetailAgent(this.data.optionId)
    if (app.globalData.userInfo) {
      this.setData({
        userId: app.globalData.userInfo.id,
        myName: app.globalData.userInfo.phone
      })
      this.collectPan(options.id)
    }
    let that = this
    computedCount((count) => {
      that.setData({
        unReadSpot: count
      });
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function (options) {
    this.setData({
      unReadSpot: getApp().globalData.unReadSpot
    });
    this.getRoster();
    this.collectPan(this.data.optionId)
  },

  getRoster() {
    let me = this;
    getRoster(() => {
      me.setData({
        member
      });
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    wx.showShareMenu({
      withShareTicket: true
    })
  }
})