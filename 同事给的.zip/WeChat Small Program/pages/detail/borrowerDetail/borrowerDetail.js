import { fetch } from "../../../utils/axios.js"
import { showToasts, navTo, getSystemInfo } from '../../../utils/wxtools'
import { goLogin, getRoster, computedCount } from '../../../utils/comMethods'

const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    user: {},
    phone: '',
    showPhone: '',
    yourlogo: '',
    borrowerName: '',
    member: [],
    isShow: false,
    isMask: false,
    id: '',
    myName: "",
    unReadSpot: 0,
    chatShow: false
  },
  onLoad: function (options) {
    this.getDetail(options)
    if (app.globalData.userInfo.name) {
      this.setData({
        myName: app.globalData.userInfo.phone,
        id: options.borId
      })
    }
    const that = this
    computedCount((count) => {
      that.setData({
        unReadSpot: count
      });
    })
    const type = getSystemInfo()
    if (type === 'android' || type === 'devtools') {
      this.setData({
        isShow: false
      })
    } else {
      this.setData({
        isShow: true
      })
    }
  },
  getDetail(params) {
    fetch.post(`/userBorrower/getBorrower`, params).then(res => {
      if (params.borId) {
        this.check(res.data.data.borrowerId, res.data.data.phone)
      }
      this.setData({
        phone: res.data.data.phone,
        borrowerName: res.data.data.borrowerName,
        yourlogo: res.data.data.borrowerLogo,
        user: res.data.data,
        chatShow: !res.data.data.phone.includes('*')
      })
      // chatShow false 手机号未查看  true 手机号已查看
    })
  },
  formatPhone(phone) {
    let str = phone
    str = str.substring(0, 3) + '****' + str.substring(7)
    this.setData({
      showPhone: str
    })
  },
  check(id, phone) {
    if (app.globalData.userInfo.roleId === 2) {
      this.checkAgentPhoneIsShow(id, phone)
    } else {
      this.checkOrganPhoneIsShow(id, phone)
    }
  },
  checkAgentPhoneIsShow(id, phone) {
    fetch.get(`/brokerResource/getBrokerResource/${app.globalData.userInfo.id}/${id}`).then(res => {
      if (res.data === 1) {
        this.setData({
          chatShow: true
        })
      } else {
        this.formatPhone(phone)
        this.setData({
          chatShow: false
        })
      }
    })
  },
  checkOrganPhoneIsShow(id, phone) {
    fetch.post(`/agencyResource/seleteStateById`, {
      agencyId: app.globalData.userInfo.id,
      borId: id
    }).then(res => {
      if (res.data.status === 200) {
        this.setData({
          chatShow: true
        })
      } else {
        this.formatPhone(phone)
        this.setData({
          chatShow: false
        })
      }
    })
  },
  lookPhone() {
    if (this.data.isShow) {
      this.setData({
        isMask: true
      })
    } else {
      if (app.globalData.userInfo.roleId === 2) {
        this.lookPhoneByAgent()
      } else {
        //机构
        this.lookPhoneByOrgan()
      }
    }
  },
  lookPhoneByAgent() {
    fetch.post(`/brokerResource/saveBrokerResource`, {
      borrowerId: this.data.id,
      brokerId: app.globalData.userInfo.id
    }).then(res => {
      if (res.data.status === 200) { // 查看成功，显示手机号
        this.setData({
          chatShow: true,
          showPhone: this.data.phone
        })
      } else if (res.data.status === 205) {
        if (app.globalData.userInfo.vip > 0) {
          showToasts('您今日查看手机号次数已经用完，请明日再进行查看，或者前往会员中心升级权益。')
        } else {
          showToasts('您还不是会员，请开通会员后查看')
        }
      } else {
        showToasts(res.data.msg)
      }
    });
  },
  lookPhoneByOrgan() {
   fetch.post(`/agencyResource/addAgencyResource`, {
      borId: this.data.id,
      agencyId: app.globalData.userInfo.id
    }).then(res => {
      if (res.data.status === 200) { // 查看成功，显示手机号
        this.setData({
          chatShow: true,
          showPhone: this.data.phone
        })
      } else if (res.data.status === 205) {
        if (app.globalData.userInfo.vip > 0) {
          showToasts('您今日查看手机号次数已经用完，请明日再进行查看，或者前往会员中心升级权益。')
        } else {
          showToasts('对不起，您暂时没有权限查看。')
        }
      } else {
        showToasts(res.data.msg)
      }
    });
  },
  cancel() {
    this.setData({
      isMask: false
    })
  },
  //立即沟通
  chat(event) {
    if (app.globalData.userInfo.name) {
      let my = wx.getStorageSync("myUsername");
      let nameList = {
        myName: my,
        myLogo: app.globalData.userInfo.image,
        your: this.data.phone,
        yourName: this.data.borrowerName,
        yourLogo: this.data.yourlogo
      };
      console.log(nameList)
      navTo("/pages/chatroom/chatroom?myName=" + nameList.myName + "&your=" + nameList.your + "&yourName=" + nameList.yourName + "&usertype=B&selfHeadImg=" + nameList.myLogo + "&yourLogo=" + nameList.yourLogo)
    } else {
      goLogin()
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      unReadSpot: app.globalData.unReadSpot
    });
     this.getRoster();
  },
  getRoster() {
    const me = this
    getRoster((member) => {
      me.setData({
        member
      });
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    wx.showShareMenu({
      withShareTicket: true
    })
  }
})