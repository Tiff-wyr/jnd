// pages/agent/personMessage/personMessage.js
const app = getApp()
import { fetch } from "../../utils/axios.js"
Page({

  /**
   * 页面的初始数据
   */
  data: {
    personData: {},
    isMask:false,
    userType: ''
  },
  getData() {
    if (app.globalData.userType === 'user') {
      fetch.get(`/userBorrower/wxSelectBorById/${app.globalData.userInfo.id}`).then(res=>{
        console.log(res)
        this.setData({ // 贷款人
          personData:res.data
        })
        
      })
    } else if (app.globalData.userType === 'agent') {
      fetch.get(`/userBroker/getUserBrokerById/${app.globalData.userInfo.id}`).then(res => {
        res.data.businessScopeInfo = res.data.businessScopeInfo.split(',')
        this.setData({ // 经纪人
          personData: res.data
        })
        console.log(this.data)
      })
    } else {
      fetch.get(`/userAgency/selectUserAgencyById/${app.globalData.userInfo.id}`).then(res => {
        this.setData({ // 机构
          personData: res.data
        })
      })
    }
  },
  look(){
     this.setData({
       isMask : true
     })
  },
  cancel(){
    this.setData({
      isMask: false
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    this.getData()
    this.setData({
      userType: app.globalData.userType
    })
  }
})